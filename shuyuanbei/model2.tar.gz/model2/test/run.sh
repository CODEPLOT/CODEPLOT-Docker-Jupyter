gunzip dataset.csv.gz
python3 /opt/model/run.py /opt/model/test /opt/model/test/cell.lable.txt
